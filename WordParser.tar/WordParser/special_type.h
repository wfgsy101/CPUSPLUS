#include<iostream>
using namespace std;

//define a struct for getting  all words in one line 
struct line
{
    char get_line[100];
};

//define a special data type 
struct special_data
{
    char string_data[10];
    int int_data;
};
