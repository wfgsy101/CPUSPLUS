#include<iostream>
#include"parser_word.h"
#include "gtest/gtest.h"

using namespace std;

int main(int argc, char* argv[])
{
    ParserWord *pParserWord = new ParserWord;



    if(!pParserWord)
    {
        cout << "Memory error!" << endl;
    }

    pParserWord->Run();

    if(NULL != pParserWord)
    {
        delete pParserWord;
        pParserWord = NULL;
    }


    testing::InitGoogleTest(); //run gtest here
    RUN_ALL_TESTS();

    return 0;
}

