#include "parser_word.h"
#include "gtest/gtest.h"

TEST(ParserWord,test) {

  int n = 3;
  char *p = "1701"; 
  ParserWord w;
  w.ConvertElement(p,&n); 
  EXPECT_EQ(1701,n); 


  char *q = "hello";
  char a[10];
  w.ConvertElement(q, a);
  EXPECT_EQ(0,strcmp("hello",a));


  char *r = "hello world 2019 !";
  struct line b;
  w.ConvertElement(r, b.get_line);
  EXPECT_EQ(0,strcmp("hello world 2019 !",b.get_line));


  char *s = "hello	2020	";
  struct special_data c;
  struct special_data * pspecial_data = &c;
  w.ConvertElement(s, pspecial_data);
  EXPECT_EQ(0,strcmp("hello",pspecial_data->string_data));
  EXPECT_EQ(2020,pspecial_data->int_data); 

}

/*main()
{

//   testing::InitGoogleTest();
   RUN_ALL_TESTS();
}
*/
