#include<iostream>
#include"special_type.h"
using namespace std;

#define COLUMN_COUNT 10
#define ROW_COUNT 10

class ParserWord
{
public:
    ParserWord();
    ~ParserWord();
    void Run(void);
    
    int Init(void);
    int Uninit(void);
    void ConvertElement(char* element, int* num);
    void ConvertElement(char* element, char* cha);
    void ConvertElement(char* element, line* pline);
    void ConvertElement(char* element, special_data* pspecial);
    void Word_Split(char* word_list, int column_count, char ** word_points);
    int ReadFile(FILE* file_fp, char* mem, int read_length);
    int GetFileLength(FILE* fp);

private:
    int file_length;
    int int_word;
    int word_total;
    int word_column;
    int word_row;
    int word_index;
    char * a[100];
    char * file_read;
    char type[10];
    char string_word[10];
    FILE * file_to_split;
    line * pline_test;
    special_data * pspecial_data;
};
