#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<iostream>
#include"parser_word.h"

using namespace std;

ParserWord::ParserWord()
{
    file_length = -1;
    int_word = -1;
    word_total = COLUMN_COUNT * ROW_COUNT;
    word_column = -1;
    word_row = -1;
    word_index = -1;    
    for(int i = 0; i < 100; i++)
    {
        a[i] = NULL;
    }    
    file_read = NULL;    
    memset(type, 0, 10);
    memset(string_word, 0, 10);
    file_to_split = NULL;
    pline_test = NULL;
    pspecial_data = NULL;
};

ParserWord::~ParserWord()
{
    file_length = -1;
    int_word = -1;
    word_total = -1;
    word_column = -1;
    word_row = -1;
    word_index = -1;    
    for(int i = 0; i < 100; i++)
    {
        a[i] = NULL;
    }    
    file_read = NULL;    
    memset(type, 0, 10);
    memset(string_word, 0, 10);
    file_to_split = NULL;
    pline_test = NULL;
    pspecial_data = NULL;
}

int ParserWord::Init(void)
{
    if((file_to_split = fopen("file_input.txt", "r")) == NULL)
    {
        cout << "file open error";

        return -1;
    }

    file_length = GetFileLength(file_to_split);
    cout << "file length is" << file_length << "\n";

    file_read = (char*)malloc(file_length);
   
    if(!pline_test)
    {
        pline_test = new line;
        if(!pline_test)
        {
            cout << "memory error !"<< "\n";
        }
    }

    if(!pspecial_data)
    {
        pspecial_data = new special_data;
        if(!pspecial_data)
        {
            cout << "memory error !"<< "\n";
        }
    }

    ReadFile(file_to_split, file_read, file_length);

    Word_Split(file_read, word_total, a);

    return 0;
}

int ParserWord::Uninit(void)
{
    if(file_read)
    {
        free(file_read);
        file_read = NULL;
    }

    fclose(file_to_split);
    
    return 0;
}

void ParserWord::Run(void)
{
    Init();

    printf("input row of word ( 1 ~ %d ) : \n", ROW_COUNT);  //input the row of the word
    scanf("%d", &word_row);
       
    printf("input column of word ( 1 ~ %d ) : \n", COLUMN_COUNT);//input the column
    scanf("%d", &word_column); 
   
    printf("input type of word ( int, string , line or special ) : \n");//input he word type
    scanf("%s", type);

    word_index = word_column + COLUMN_COUNT * ( word_row -1 ) - 1; //caculate the index of the word 
    if(strcmp("int", type) == 0)           
    {
        ConvertElement(a[word_index], &int_word);
        printf("row: %d, column: %d, type: %s, value: %d\n", word_row, word_column, type, int_word);   
    }
    if(strcmp("string", type) == 0)  
    { 
        ConvertElement(a[word_index], string_word);
        printf("row: %d, column: %d, type: %s, value: %s\n", word_row, word_column, type, string_word);
    }



   if(strcmp("line",type)==0)
   {
        
 
   ConvertElement(a[word_index],pline_test);
   printf("row: %d, column: %d, type: %s, value: %s \n",word_row,word_column,type,pline_test->get_line);
    }


   if(strcmp("special",type)==0)
   {
        
 
   ConvertElement(a[word_index],pspecial_data);
   printf("row: %d, column: %d, type: %s, value: %s %d\n",word_row,word_column,type,pspecial_data->string_data,pspecial_data->int_data);
    }

    Uninit();
}

//convert to the int type
void ParserWord::ConvertElement(char* element, int* num)
{
    if(element != NULL)
    {
        sscanf(element, "%d", num);
    }
}

//convert to the string type
void ParserWord::ConvertElement(char* element, char* cha)
{
    if(element != NULL && cha != NULL)
    {
        char* source_element = element;
        char* dest_element = cha;
        while(*source_element != '\t' && *source_element != '\n' && *source_element != '\0')
        {
            *dest_element++ = *source_element++;
        }
        *dest_element ='\0';
    }
}

// get the words start from element till the end of the line  
void ParserWord::ConvertElement(char* element, line* pline)
{
   if(element != NULL)
   {
       sscanf(element, "%[^\n]", pline->get_line);
   }
}

// get the special data which contain one word in string and one int 
void ParserWord::ConvertElement(char* element, special_data* pspecial)
{
   char a[10] ; 
   if(element != NULL)
   {
       sscanf(element, "%[^\t]", pspecial->string_data);
       sscanf(element, "%*[^\t]\t%[^\t]", a);
       sscanf(a, "%d", &pspecial->int_data);
   }
}

//split the word list to words, ( separate by \t and \n , word_list : beginning address of file, word_points : point to each word 
void ParserWord::Word_Split(char* word_list, int column_count, char ** word_points)
{
    int word_pos = 0;
    int i = 0;
    if(word_list == NULL && column_count < 0)
    {
        cout<< "input error"<<"\n";
    }
    word_points[word_pos] = &word_list[i];
    word_pos++;
    for(i = 1; word_list[i] != '\0'; i++)
    {
        if( word_list[i] == '\t' || word_list[i] == '\n')
        {
            word_points[word_pos++] = &word_list[i+1];
        }  

    }
    printf("word_pos and column_ , i: %d %d %d\n", word_pos, column_count, i);
    if(word_pos != column_count)
    {
        cout << "split error: wrong counts of words output" << "\n";
    }
}

//get the total number of words
int ParserWord::GetFileLength(FILE *fp)
{
     int length;
     fseek(fp, 0, SEEK_END);
     length = ftell(fp);
     fseek(fp, 0, SEEK_SET);

     return length;
}

//read file to memory
int ParserWord::ReadFile(FILE * file_fp, char * mem, int read_length)
{
   FILE *fp;
   int length = 0;
   char * mem_copy = mem;
   fp = file_fp;
   length = read_length; 
   length = GetFileLength(fp);
   fread(mem_copy, length, 1, fp);
   *(mem_copy+length-1) = '\0';

   return 0;
}

