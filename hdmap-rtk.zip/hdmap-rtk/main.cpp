#include <string>
#include "rtk_map.h"
#include "rtk_map_processor.h"
#include "rtk_map_writer.h"
#include "common_util.h"
#include "log_record.h"

int main(int argc, char const *argv[]) {
    
    if (argc < 4) {
        std::string err_msg = "[Usage] .output/bin/rtk_map in_rtk_file out_hdmap_file lane_width";
        adu::hdmap::LogMessage log_msg;
        log_msg.set_msg(err_msg);
        adu::hdmap::Singleton<adu::hdmap::LogRecord<adu::hdmap::LogMessage>>::instance()
            ->record_error(log_msg);
        return -1;
    }

    adu::hdmap::RTKMapProcessor rtk_map_processor;
    adu::hdmap::RTKMap rtk_map;
    std::string in_path = argv[1];
    rtk_map_processor.set_lane_width(std::atof(argv[3]));
    if (!rtk_map_processor.process(in_path, &rtk_map)) {
        std::string err_msg = "fail to process rtk map " + in_path;
        adu::hdmap::LogMessage log_msg;
        log_msg.set_msg(err_msg);
        adu::hdmap::Singleton<adu::hdmap::LogRecord<adu::hdmap::LogMessage>>::instance()
            ->record_error(log_msg);
        return -1;
    }

    adu::hdmap::RTKMapWriter map_writer;
    std::string output_path = argv[2];
    if (!map_writer.write(output_path, rtk_map)) {
        std::string err_msg = "fail to write rtk map to file " + output_path;
        adu::hdmap::LogMessage log_msg;
        log_msg.set_msg(err_msg);
        adu::hdmap::Singleton<adu::hdmap::LogRecord<adu::hdmap::LogMessage>>::instance()
            ->record_error(log_msg);
        return -1;
    }

    return 0;
}
