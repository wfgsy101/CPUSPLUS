#ifndef BAIDU_ADU_HDMAP_RTK_MAP_WRITER_DEFINE_H
#define BAIDU_ADU_HDMAP_RTK_MAP_WRITER_DEFINE_H

#include "map.pb.h"
#include <string>
#include <memory>
#include <unordered_map>

namespace adu {
namespace hdmap {

typedef ::adu::common::hdmap::Point     CommonPbPoint;
typedef ::adu::common::hdmap::Map       CommonPbMap;
typedef ::adu::common::hdmap::Header    CommonPbHeader;
typedef ::adu::common::hdmap::Road      CommonPbRoad;

typedef std::shared_ptr< ::adu::common::hdmap::Road>        RoadPtr;
typedef std::shared_ptr< ::adu::common::hdmap::Lane>        LanePtr;
typedef std::shared_ptr< ::adu::common::hdmap::LineSegment> LineSegmentPtr;

typedef std::map<std::string, LanePtr> LaneTable;
typedef std::map<std::string, RoadPtr> RoadTable;

} // namespace hdmap
} // namespace adu

#endif // BAIDU_ADU_HDMAP_RTK_MAP_WRITER_DEFINE_H