#ifndef BAIDU_ADU_HDMAP_RTK_POINT_H
#define BAIDU_ADU_HDMAP_RTK_POINT_H

#include <assert.h>
#include <cmath>
#include <string>
#include <vector>
#include <iostream>

namespace adu {
namespace hdmap {

const double kMathEpsilon = 1e-10;

class Point3D {
public:
    void set_x(double x) { _x = x;}
    void set_y(double y) { _y = y;}
    void set_z(double z) { _z = z;}

    double x() const {return _x;}
    double y() const {return _y;}
    double z() const {return _z;}

public:
    double _x;
    double _y;
    double _z;

    Point3D() : _x(0.0), _y(0.0), _z(0.0) {}
    Point3D(double x, double y, double z) : _x(x), _y(y), _z(z) {}
    Point3D(const Point3D &rhs) {
        if (this != &rhs) {
            _x = rhs._x;
            _y = rhs._y;
            _z = rhs._z;
        }
    }

    Point3D &operator=(const Point3D &rhs) {
        if (this != &rhs) {
            _x = rhs._x;
            _y = rhs._y;
            _z = rhs._z;
        }

        return *this;
    }

    bool operator==(const Point3D &rhs) {
        if (fabs(_x - rhs._x) < 1e-5 &&
            (fabs(_y - rhs._y) < 1e-5) &&
            (fabs(_z - rhs._z) < 1e-5)) {
            return true;
        }

        return false;
    }

    Point3D operator-(const Point3D &rhs) const {
        return Point3D(_x - rhs._x, _y - rhs._y, _z - rhs._z);
    }
    Point3D operator+(const Point3D &rhs) const {
        return Point3D(_x + rhs._x, _y + rhs._y, _z + rhs._z);
    }

    Point3D operator*(double d) { return Point3D(_x * d, _y * d, _z * d); }
    Point3D operator / (double d) { return Point3D(_x / d, _y / d, _z / d); }

    double norm_2() const {
        return sqrt(_x * _x + _y * _y + _z * _z);
    }

    double heading() const {
        // not support
        assert(0);
        return 0.0;
    }

    double distance_to(const Point3D& pt) const {
        return sqrt((_x - pt._x) * (_x - pt._x) 
            + (_y - pt._y) * (_y - pt._y)
            + (_z - pt._z) * (_z - pt._z));
    }

    const std::string to_string() const;
};

class Point2D {
public:
    void set_x(double x) { _x = x;}
    void set_y(double y) { _y = y;}

    double x() const {return _x;}
    double y() const {return _y;}

    double _x;
    double _y;

    Point2D() : _x(0.0), _y(0.0) {}
    Point2D(double x, double y) : _x(x), _y(y) {}
    Point2D(const Point2D &rhs) {
        if (this != &rhs) {
            _x = rhs._x;
            _y = rhs._y;
        }
    }

    Point2D &operator=(const Point2D &rhs) {
        if (this != &rhs) {
            _x = rhs._x;
            _y = rhs._y;
        }

        return *this;
    }

    bool operator<(const Point2D &rhs) const {
        if (_x < rhs._x) {
            return true;
        } else if (fabs(_x - rhs._x) < 1e-5 && (_y < rhs._y)) {
            return true;
        } else {
            return false;
        }
    }
    bool operator==(const Point2D &rhs) const {
        if (fabs(_x - rhs._x) < 1e-5 && fabs(_y - rhs._y) < 1e-5) {
            return true;
        } else {
            return false;
        }
    }

    Point2D operator-(const Point2D &rhs) const {
        return Point2D(_x - rhs._x, _y - rhs._y);
    }
    Point2D operator+(const Point2D &rhs) const {
        return Point2D(_x + rhs._x, _y + rhs._y);
    }
    Point2D operator/(double d) { return Point2D(_x / d, _y / d); }
    Point2D operator*(double d) { return Point2D(_x * d, _y * d); }

    double norm_2() const {
        return sqrt(_x * _x + _y * _y);
    }

    double heading() const {return atan2(_y, _x);}

    double distance_to(const Point2D& pt) const {
        return sqrt((_x - pt._x) * (_x - pt._x) 
            + (_y - pt._y) * (_y - pt._y));
    }

    const std::string to_string() const;
};

class CRect {
public:
    CRect() : _left_up(0.0, 0.0, 0.0), _right_down(0.0, 0.0, 0.0){

    }

    CRect(Point3D &left_up, Point3D &right_down) {
        _left_up = left_up;
        _right_down = right_down;
    }

public:
    bool is_in_rect(Point3D &pt) {
        double xr = (pt._x - _left_up._x) * (pt._x - _right_down._x);
        double yr = (pt._y - _left_up._y) * (pt._y - _right_down._y);

        return ((xr <= 0.0) && (yr <= 0.0));
    }

    double width() {
        return _right_down._x - _left_up._x;
    }

    double height() {
        return _left_up._y - _right_down._y;
    }

    Point3D left_upper_pt() {
        return _left_up;
    }

    Point3D right_down_pt() {
        return _right_down;
    }

private:
    Point3D _left_up;
    Point3D _right_down;
};

template <class T>
void print_point_set(std::vector<T>& point_set) {
    for (auto& pt : point_set) {
        std::cout << pt.to_string() << std::endl;
    }
}

template <typename T>
int sgn(T val) {
    const T eps = 0;
    if (val < -eps) {
        return -1;
    } else if (val > eps) {
        return 1;
    }

    return 0;
}

template <> int sgn(double val);

struct DefaultOrientation_2_Trait {
    typedef double  RT;
    typedef Point3D Point_2;
};

struct Orientation_2_Trait {
    typedef double  RT;
    typedef Point2D Point_2;
};

template <typename K>
struct orientation_2 {
    typedef typename K::RT            RT;
    typedef typename K::Point_2       Point_2;

    int operator()(const Point_2 &p, const Point_2 &q, const Point_2 &r) const {
        RT qpx = q.x() - p.x();
        RT qpy = q.y() - p.y();
        RT rqx = r.x() - q.x();
        RT rqy = r.y() - q.y();
        return sgn(qpx * rqy - rqx * qpy );
    }
};

} // namespace hdmap
} // namespace adu

#endif // BAIDU_ADU_HDMAP_RTK_POINT_H
