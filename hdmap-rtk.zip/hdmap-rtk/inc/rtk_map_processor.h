#ifndef BAIDU_ADU_HDMAP_RTK_MAP_PROCESSOR_H
#define BAIDU_ADU_HDMAP_RTK_MAP_PROCESSOR_H

#include "rtk_map.h"

namespace adu {
namespace hdmap {

class RTKMapProcessor {
public:
    RTKMapProcessor() = default;
    ~RTKMapProcessor() = default;

public:
    bool process(const std::string& filename, RTKMap* map);
    void set_lane_width(const double width);
    void smooth_border(const std::vector<Point3D>& origin_border,
                    std::vector<Point3D>& border);

private:
    bool load_trajectory(const std::string& filename, std::vector<Point3D>& rtk_points);
    bool generate_map(const std::vector<Point3D>& rtk_sparse_points, RTKMap* map);
    void split_border(const std::vector<Point3D>& left_border,
                    const std::vector<Point3D>& right_border,
                    const std::vector<Point3D>& center_line,
                    std::vector<std::vector<Point3D>>& left_borders,
                    std::vector<std::vector<Point3D>>& center_lines,
                    std::vector<std::vector<Point3D>>& right_borders);
    void fill_data_struct(const std::vector<Point3D>& left_border,
                    const std::vector<Point3D>& right_border,
                    const std::vector<Point3D>& center_line, RTKMap* map);

private:
    double _lane_width = 3.5;

};

} // namespace hdmap
} // namespace adu

#endif // BAIDU_ADU_HDMAP_RTK_MAP_PROCESSOR_H