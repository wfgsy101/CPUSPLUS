#ifndef BAIDU_ADU_HDMAP_RTK_MAP_WRITER_H
#define BAIDU_ADU_HDMAP_RTK_MAP_WRITER_H

#include <string>

#include "rtk_map.h"
#include "rtk_map_writer_define.h"

namespace adu {
namespace hdmap {

class RTKMapWriter {
public:
    RTKMapWriter() = default;
    ~RTKMapWriter() = default;

public:
    bool write(const std::string& output_filename, const RTKMap& hdmap_data);

    bool set_pb_header(const RTKMap &hdmap_data, CommonPbHeader *header);

    void set_pb_road(const RTKMap& hdmap_data, RoadTable& road_table);

    void set_pb_lane(const RTKMap& hdmap_data, LaneTable& lane_table);

    void add_roads(const RoadTable& road_table, CommonPbMap& common_pb_map);

    void add_lanes(const LaneTable &lane_table, CommonPbMap& common_pb_map);
};

} // namespace hdmap
} // namespace adu

#endif // BAIDU_ADU_HDMAP_RTK_MAP_WRITER_H
