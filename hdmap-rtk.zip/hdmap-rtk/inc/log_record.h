#ifndef BAIDU_ADU_HDMAP_RTK_LOG_RECORD_H
#define BAIDU_ADU_HDMAP_RTK_LOG_RECORD_H

#include <vector>
#include <string>
#include <map>
#include <array>
#include "point.h"
#include <boost/assign/list_of.hpp>

namespace adu {
namespace hdmap {

enum ElementType {
    ELEMENT_TYPE_UNKNOWN = 0,
    HEADER,
    ROAD,
    ROADSECTION,
    LANE,
    JUNCTION,
    CROSSWALK,
    STOPSIGN,
    YIELDSIGN,
    PARKINGSPACE,
    TRAFFICLIGHT,
    SPEEDBUMP,
    CLEARAREA,
    AUTOCONN,
    STOPLINE,
    OVERLAP,
    ELEMENT_TYPE_MAX,
};

const std::array<std::string, ELEMENT_TYPE_MAX> ElementTypeString = {
    "Unknown",
    "Header",
    "Road",
    "RoadSection",
    "Lane",
    "Junction",
    "CrossWalk",
    "StopSign",
    "YieldSign",
    "ParkingSpace",
    "TrafficLight",
    "SpeedBump",
    "ClearArea",
    "AutoConn",
    "StopLine",
    "Overlap",
};

const std::string LOG_LABEL = "LABEL_DATA";
const std::string LOG_FORMAT_VERSION = "1";

extern std::string filter_invalid_json_char(const std::string& raw);

class LogMessage {
public:
    LogMessage() : _src(LOG_LABEL) {}
    ~LogMessage() {}

public:
    std::vector<std::string> _ids;
    std::vector<ElementType> _etypes;
    std::vector<std::vector<Point3D>> _ptss;
    std::string  _info;
    std::string  _src;

public:
    void add_id(const std::string& id) {
        _ids.push_back(id);
    }
    void add_type(const ElementType& etype) {
        _etypes.push_back(etype);
    }
    void add_pts(const std::vector<Point3D>& pts) {
        _ptss.push_back(pts);
    }
    void set_msg(const std::string& info) {
        _info = info;
    }

    std::string to_json() const {
        std::string json = "\"src\":\"" + _src + "\",";

        // types
        json += "\"types\":[";
        if (_etypes.size() <= 0) {
            json += "\"";
            json += ElementTypeString[ELEMENT_TYPE_UNKNOWN];
            json += "\"";
        } else {
            for (size_t i = 0; i < _etypes.size(); ++i) {
                if (i > 0) {
                    json += ",";
                }
                json += "\"";
                json += ElementTypeString[_etypes[i]];
                json += "\"";
            }
        }
        json += "],";

        if (_ids.size() > 0) {
            json += "\"ids\":[";
            for (size_t i = 0; i < _ids.size(); ++i) {
                if (i > 0) {
                    json += ",";
                }
                json += "\"";
                json += _ids[i];
                json += "\"";
            }
            json += "],";
        }

        bool is_effective_point_exist = false;
        const size_t max_loc_size = 30;
        std::string json_loc = "\"locs\":[";
        std::string json_loc_pts = "";
        for (auto& pts : _ptss) {
            if (!json_loc_pts.empty()) {
                json_loc_pts += ",";
            }
            if (pts.size() <= 0) {
                continue;
            }
            std::string json_loc_pt;
            json_loc_pts += "[";
            size_t loc_cnt = 0;
            for (auto& pt : pts) {
                if (!json_loc_pt.empty()) {
                    json_loc_pt += ",";
                }
                json_loc_pt += "{";
                json_loc_pt += "\"x\":" + std::to_string(pt._x) + ",";
                json_loc_pt += "\"y\":" + std::to_string(pt._y) + ",";
                json_loc_pt += "\"z\":" + std::to_string(pt._z);
                json_loc_pt += "}";

                is_effective_point_exist = true;

                if (loc_cnt++ > max_loc_size) {
                    break;
                }
            }
            json_loc_pts += json_loc_pt;
            json_loc_pts += "]";
        }

        if (!is_effective_point_exist) {
            json_loc = "";
        } else {
            json_loc += json_loc_pts;
            json_loc += "]";
        }

        if (!json_loc.empty()) {
            json += json_loc + ",";
        }
        json += "\"info\":\"" + filter_invalid_json_char(_info) + "\"";

        return json;
    }
};

// 日志记录对象
template<class P>
class LogRecord {
public:
    // 错误级别
    enum LogLevel {
        INFO,
        WARNING,
        ERROR,
    };

public:
    void record_info(const P& log_policy) {
        _level = LogRecord::INFO;
        std::cerr << to_json(log_policy) << std::endl;
    }

    void record_warning(const P& log_policy) {
        _level = LogRecord::WARNING;
        std::cerr << to_json(log_policy) << std::endl;
    }

    void record_error(const P& log_policy) {
        _level = LogRecord::ERROR;
        std::cerr << to_json(log_policy) << std::endl;
    }

private:
    std::string to_json(const P& log_policy) const {
        std::string json = "{\"fv\":" + LOG_FORMAT_VERSION + ",";
        json += "\"level\":\"" + _level_2_string[_level] + "\",";
        std::string policy_msg = log_policy.to_json();
        json += policy_msg;
        json += "}";

        return json;
    }

private:
    static std::map<LogLevel, std::string> _level_2_string;
    static LogRecord* s_log_record_instance;

    // 日志级别
    LogLevel _level;
};

template<class P>
std::map<typename LogRecord<P>::LogLevel, std::string>
LogRecord<P>::_level_2_string = 
                    boost::assign::map_list_of(LogRecord<P>::INFO, "INFO")
                                            (LogRecord<P>::WARNING, "WARNING")
                                            (LogRecord<P>::ERROR, "ERROR");
template<class P>
LogRecord<P>* LogRecord<P>::s_log_record_instance = nullptr;

} // namespace hdmap
} // namespace adu

#endif  // BAIDU_ADU_HDMAP_RTK_LOG_RECORD_H
