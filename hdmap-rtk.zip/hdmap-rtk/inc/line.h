#ifndef BAIDU_ADU_HDMAP_RTK_LINE_H
#define BAIDU_ADU_HDMAP_RTK_LINE_H

#include <limits>
#include "point.h"

namespace adu {
namespace hdmap {

template<typename Traits_L>
class Line3 {
public:
    typedef typename Traits_L::RT                       RT;
    typedef typename Traits_L::Point_3                  Point_3;
    typedef typename std::vector<Point_3>               Container_L;
    typedef typename Container_L::iterator              Vertex_iterator;
    typedef typename Container_L::iterator              Vertex_const_iterator;
    typedef typename Container_L::reverse_iterator      vertex_reverse_const_iterator;

    Line3() {}

    Line3(const Line3<Traits_L>& line_3)
    : _container(line_3._container) {}

    template <class InputIterator>
    Line3(InputIterator first, InputIterator last)
        : _container() {
        std::copy(first, last, std::back_inserter(_container));
    }

    Line3& operator=(const Line3<Traits_L>& line_3) {
        if (this != &line_3) {
            _container = line_3._container;
        }
        return *this;
    }

    Line3& operator=(Line3<Traits_L>&& line_3) {
        if (this != &line_3) {
            _container = std::move(line_3._container);
        }
        return *this;
    }

    template <class InputIterator>
    void insert(Vertex_iterator i,
                InputIterator first,
                InputIterator last) { 
        _container.insert(i, first, last);
    }

    template <class InputIterator>
    void insert_front(
                InputIterator first,
                InputIterator last) { 
        _container.insert(_container.begin(), first, last);
    }

    template <class InputIterator>
    void insert_back(
                InputIterator first,
                InputIterator last) { 
        _container.insert(_container.end(), first, last);
    }

    void push_back(const Point_3& x) {
        _container.insert(_container.end(), x);
    }

    const Point_3& vertex(int i) const { 
        return *(_container.begin() + i);
    }

    const Point_3& operator[](int i) const {
        return vertex(i);
    }

    Point_3& vertex(int i) { 
        return *(_container.begin() + i);
    }

    Point_3& operator[](int i) {
        return vertex(i);
    }

    Vertex_const_iterator vertices_begin() const {
        return const_cast<Line3&>(*this)._container.begin();
    }
    Vertex_const_iterator vertices_end() const {
        return const_cast<Line3&>(*this)._container.end();
    }
    vertex_reverse_const_iterator vertices_rbegin() const {
        return const_cast<Line3&>(*this)._container.rbegin();
    }
    vertex_reverse_const_iterator vertices_rend() const {
        return const_cast<Line3&>(*this)._container.rend();
    }

    const Point_3& back() const {
        return _container.back();
    }

    const Point_3& front() const {
        return _container.front();
    }

    void clear() {
        _container.clear();
    }

    std::size_t size() const {
        return _container.size();
    }

    void resize(const size_t n) {
        _container.resize(n);
    }

    bool is_empty() const {
        return _container.empty();
    }

    const Container_L& container() const {
        return _container;
    }

    double length() const {
        double len = 0.0;
        if (_container.size() > 1) {
            for (size_t i = 0; i + 1 < size(); ++i) {
                len += _container[i].distance_to(_container[i + 1]);
            }
        }

        return len;
    }

private:
    Container_L     _container;
};

struct Trait_L {
    typedef double RT;
    typedef Point3D Point_3;
};

typedef Line3<Trait_L> Line3D;

template<typename Traits = Trait_L>
std::vector<typename Traits::Point_3> points_from_line(const Line3<Traits>& line) {
    std::vector<typename Traits::Point_3> points(line.vertices_begin(),
                                                line.vertices_end());
    return points;
}
template<typename Traits = Trait_L>
typename Traits::Point_3 boundary_lb_point(const Line3<Traits>& line) {

    double min_x = std::numeric_limits<double>::max();
    double max_x = std::numeric_limits<double>::min();
    double min_y = std::numeric_limits<double>::max();
    double max_y = std::numeric_limits<double>::min();

    if (line.size() > 0) {
        min_x = max_x = line[0].x();
        max_x = max_y = line[0].y();
    }

    for (size_t i = 0; i < line.size(); ++i) {
        if (min_x > line[i].x()) {
            min_x = line[i].x();
        } else if (max_x < line[i].x()) {
            max_x = line[i].x();
        }

        if (min_y > line[i].y()) {
            min_y = line[i].y();
        } else if (max_y < line[i].y()) {
            max_y = line[i].y();
        }
    }

    typename Traits::Point_3 lb_pt(min_x, min_y, 0.0);

    return lb_pt;
}

} // namespace hdmap
} // namespace adu

#endif // BAIDU_ADU_HDMAP_RTK_LINE_H
