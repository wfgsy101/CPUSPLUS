#ifndef BAIDU_ADU_HDMAP_RTK_MAP_LANE_WRITER_H
#define BAIDU_ADU_HDMAP_RTK_MAP_LANE_WRITER_H

#include <string>

#include "rtk_map.h"
#include "rtk_map_writer_define.h"

namespace adu {
namespace hdmap {

class RTKMapLaneWriter {
public:
    RTKMapLaneWriter() = default;
    ~RTKMapLaneWriter() = default;

public:
public:
    void set_pb_boundary_edge(std::vector<Point3D>& pts,
                            ::adu::common::hdmap::BoundaryEdge_Type type,
                            ::adu::common::hdmap::BoundaryEdge* edge);
    void set_pb_road(const RTKMap& hdmap_data, RoadTable& road_table);
    void set_pb_lane(const RTKMap& hdmap_data, LaneTable& lane_table);

    void calc_lane_boundary(const DataLane& data_lane, LanePtr& lane);
    void calc_lane_left_boundary(const DataLaneBorder& lane_left_border,
        ::adu::common::hdmap::CurveSegment *lane_left_boundary);
    void calc_lane_right_boundary(const DataLaneBorder& lane_right_border,
        ::adu::common::hdmap::CurveSegment *lane_right_boundary);
    void calc_lane_central_line(const DataLane& data_lane, LanePtr &lane);
    double calc_lane_length(const ::adu::common::hdmap::LineSegment &lane_segment);
    ::adu::common::hdmap::Lane::LaneTurn get_lane_turn(Lane_TurnType turn_type);
    ::adu::common::hdmap::Lane::LaneType get_lane_type(Lane_LaneType lane_type);
    ::adu::common::hdmap::Lane::LaneDirection get_lane_direction(
                                                LaneDirection lane_direction);

    void calc_lane_heading(LanePtr& lane);
    void add_lane_connections(const DataLane& data_lane, LanePtr& common_pb_lane);

    ::adu::common::hdmap::LaneBoundaryType::Type to_boundary_type(
                                            const RoadMarkType line_typeType);
    void set_boundary_type(const DataLane *lane, LanePtr& common_pb_lane);
    void set_lane_neighbor(const RoadSection& lane_section,int index,
                        LanePtr& lane);
    void calc_lane_width(LanePtr& lane);
    void add_lane_width(const DataLane& data_lane, LanePtr& lane);
    void get_line_type(const RoadMarkType line_type,
                    ::adu::common::hdmap::LaneBoundary::Type &type);
};

} // namespace hdmap
} // namespace adu

#endif // BAIDU_ADU_HDMAP_RTK_MAP_LANE_WRITER_H
