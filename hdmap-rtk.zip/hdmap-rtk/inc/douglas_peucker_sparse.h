#ifndef BAIDU_ADU_HDMAP_RTK_DOUGLAS_PEUCKER_SPARSE_H
#define BAIDU_ADU_HDMAP_RTK_DOUGLAS_PEUCKER_SPARSE_H

#include <vector>
#include "point.h"
#include "common_define.h"
#include "common_util.h"

namespace adu {
namespace hdmap {

class DouglasPeucker {
public:
    void douglas_peucker(const std::vector<Point3D>& input,
                        std::vector<Point3D>& output,
                        const double tolerance);

private:
    double distance_pt_to_line(const std::vector<Point3D>& input,
                            size_t t_index, const size_t s_index,
                            const size_t e_index);

private:
    struct StartEnd {
        StartEnd(size_t l, size_t r) : l_index(l), r_index(r) {}
        size_t l_index;
        size_t r_index;
    };

};

} // namespace hdmap
} // namespace adu

#endif // BAIDU_ADU_HDMAP_RTK_DOUGLAS_PEUCKER_SPARSE_H
