#ifndef BAIDU_ADU_HDMAP_RTK_COMMON_UTIL_H
#define BAIDU_ADU_HDMAP_RTK_COMMON_UTIL_H

#include <vector>
#include "point.h"

namespace adu {
namespace hdmap {

const double DB_EPSINON = 1e-5;

static inline bool is_zero(double f) {
    return f < DB_EPSINON && f > -DB_EPSINON; 
}

template <class T>
class Singleton {
public:
    static T* instance() {
        static T s_instance;
        return &s_instance;
    };
};

} // namespace hdmap
} // namespace adu

#endif // BAIDU_ADU_HDMAP_RTK_COMMON_UTIL_H
