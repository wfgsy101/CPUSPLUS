#ifndef BAIDU_ADU_HDMAP_RTK_MAP_H
#define BAIDU_ADU_HDMAP_RTK_MAP_H

#include <string>
#include <vector>
#include <unordered_map>
#include <set>

#include "point.h"
#include "line.h"
#include "polygon.h"

#include "common_define.h"

namespace adu {
namespace hdmap {

struct DataHeader {
    std::string data_version;
    std::string data_date;
    std::string data_district;
    std::string map_id;
    unsigned long format_version;

    DataHeader() : data_version("1.4000"),
        data_date("201611071343") {

    }
};

class PolygonBoundary {
public:
    Polygon3D to_polygon() const {
        Polygon3D polygon;
        polygon.insert(polygon.vertices_end(), _left_boundary.vertices_begin(),
                    _left_boundary.vertices_end());
        if (_front_side.size() > 2) {
        polygon.insert(polygon.vertices_end(), _front_side.vertices_begin() + 1,
                    _front_side.vertices_end() - 1);
        }
        polygon.insert(polygon.vertices_end(), _right_boundary.vertices_begin(),
                    _right_boundary.vertices_end());
        if (_back_side.size() > 2) {
        polygon.insert(polygon.vertices_end(), _back_side.vertices_begin() + 1,
                    _back_side.vertices_end() - 1);
        }

        return polygon;
    }

    std::vector<Point3D> to_points() const {
        std::vector<Point3D> points;
        std::copy(_left_boundary.vertices_begin(),
                _left_boundary.vertices_end(),
                std::back_inserter(points));
        if (_front_side.size() > 2) {
        std::copy(_front_side.vertices_begin() + 1,
                _front_side.vertices_end() - 1,
                std::back_inserter(points));
        }
        std::copy(_right_boundary.vertices_begin(),
                _right_boundary.vertices_end(),
                std::back_inserter(points));
        if (_back_side.size() > 2) {
        std::copy(_back_side.vertices_begin() + 1,
                _back_side.vertices_end() - 1,
                std::back_inserter(points));
        }

        return points;
    }
public:
    Line3D _left_boundary;
    Line3D _right_boundary;
    Line3D _front_side;
    Line3D _back_side;
};

class RoadBoundary : public PolygonBoundary {
public:
    std::vector<Polygon3D> _holes;
};

struct LaneSampleAssociation {
    double s;
    double width;
};

class DataLaneBorder {
public:
    RoadMarkType _type;
    Line3D _border;
    bool   _artificial;

public:
    DataLaneBorder() : _artificial(false) {}
};

class DataLane {
public:
    // copy from label data
    std::string _id;

    double _max_speed;
    double _min_speed;

    Lane_LaneType _lane_type;
    Lane_TurnType _turn_type;
    // std::set<Lane_TurnType> _next_turn_types;
    LaneDirection _direction;
    DataLaneBorder _left_border;
    DataLaneBorder _right_border;

    Line3D _center_line;
    double _length;

    std::set<std::string> _predessors;
    std::set<std::string> _successors;

    std::set<std::string> _left_neighbor_lane_ids;
    std::set<std::string> _right_neighbor_lane_ids;

    std::set<std::string> _left_reverse_neighbor_lane_ids;
    std::set<std::string> _right_reverse_neighbor_lane_ids;

    std::set<std::string> _overlap_ids;

    std::vector<LaneSampleAssociation> _left_dis;
    std::vector<LaneSampleAssociation> _right_dis;

    std::vector<LaneSampleAssociation> _left_road_dis;
    std::vector<LaneSampleAssociation> _right_road_dis;

public:
    DataLane() : _max_speed(0.0),
    _min_speed(0.0),
    _direction(LANE_DIRECTION_FORWARD),
    _length(0.0) {}
};

class RoadSection {
public:
    std::string _id;
    std::vector<DataLane> _lanes;

    RoadBoundary  _boundary;
};

class Road {
public:
    std::string _id;
    std::vector<RoadSection> _sections;
    RoadBoundary  _boundary;

public:
    Road() {}
};

class RTKMap {
public:
    DataHeader _header;
    std::unordered_map<std::string, Road> _roads;
};

} // namespace hdmap
} // namespace adu

#endif // BAIDU_ADU_HDMAP_RTK_MAP_H