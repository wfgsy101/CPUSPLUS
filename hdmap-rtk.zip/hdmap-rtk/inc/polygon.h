#ifndef BAIDU_ADU_HDMAP_RTK_POLYGON_H
#define BAIDU_ADU_HDMAP_RTK_POLYGON_H

#include <vector>
#include <iterator>

#include "vec2d.h"
#include "segment2d.h"
#include "polygon2d.h"
#include "log_record.h"
#include "line.h"
#include "common_util.h"

// #include <CGAL/Exact_predicates_exact_constructions_kernel.h>
// #include <CGAL/Boolean_set_operations_2.h>
#include <list>

// typedef CGAL::Exact_predicates_exact_constructions_kernel Kernel;
// typedef Kernel::Point_2                                   Point_2;
// typedef CGAL::Polygon_2<Kernel>                           Polygon_2;
// typedef CGAL::Polygon_with_holes_2<Kernel>                Polygon_with_holes_2;
// typedef std::list<Polygon_with_holes_2>                   Pwh_list_2;

namespace adu {
namespace hdmap {

template <class Traits_P, class Container_P
        = std::vector<typename Traits_P::Point> >
class Polygon {
public:
    typedef Traits_P Traits;
    typedef Container_P Container;

    // The number type of the coordinates of the points of the polygon.
    typedef typename Traits_P::FT FT;
    // The point type of the polygon.
    typedef typename Traits_P::Point Point;
    typedef typename Container::iterator       Vertex_iterator;
    typedef typename Container::iterator       Vertex_const_iterator;

    Polygon() {}

    Polygon(const Polygon<Traits_P, Container_P>& polygon)
    : _container(polygon._container) {}

    template <class InputIterator>
    Polygon(InputIterator first, InputIterator last)
        : _container() {
        std::copy(first, last, std::back_inserter(_container));
    }

    Polygon& operator=(const Polygon<Traits_P>& polygon) {
        if (this != &polygon) {
            _container = polygon._container;
        }
        return *this;
    }

    Polygon& operator=(const Polygon<Traits_P>&& polygon) {
        if (this != &polygon) {
            _container = std::move(polygon._container);
        }
        return *this;
    }

    template <class InputIterator>
    void insert(Vertex_iterator i,
                InputIterator first,
                InputIterator last) { 
        _container.insert(i, first, last);
    }

    void push_back(const Point& x) {
        _container.insert(_container.end(), x);
    }

    const Point& vertex(int i) const { 
        return *(_container.begin() + i);
    }

    Point& vertex(int i) {
        return *(_container.begin() + i);
    }

    const Point& operator[](int i) const {
        return vertex(i);
    }

    Point& operator[](int i) {
        return vertex(i);
    }

    const Container_P& container() const {
        return _container;
    }

    Vertex_iterator vertices_begin() { 
        return _container.begin(); 
    }

    Vertex_iterator vertices_end() {
        return _container.end();
    }
    Vertex_const_iterator vertices_begin() const {
        return const_cast<Polygon&>(*this)._container.begin();
    }

    Vertex_const_iterator vertices_end() const {
        return const_cast<Polygon&>(*this)._container.end();
    }

    void clear() {
        _container.clear();
    }

    std::size_t size() const {
        return _container.size();
    }

    bool is_empty() const {
        return _container.empty();
    }

    // bool join(const Polygon<Traits_P>& polygon) const {
    //     // Construct the two input polygons.
    //     Polygon_2 p;
    //     for (auto& polygon_1_point : container()){
    //         Point_2 polygon2d_1_point(
    //             polygon_1_point._x, polygon_1_point._y);
    //         p.push_back(polygon2d_1_point);
    //     }
    //     Polygon_2 q;
    //     for (auto& polygon_2_point : polygon.container()){
    //         Point_2 polygon2d_2_point(
    //             polygon_2_point._x, polygon_2_point._y);
    //         q.push_back(polygon2d_2_point);
    //     }
    //     // Compute the union of P and Q.
    //     Polygon_with_holes_2 union_r;
    //     if (CGAL::join (p, q, union_r)) {
    //         typename CGAL::Polygon_2<Kernel,
    //                                     Container>::Vertex_const_iterator vit;
    //         _container.clear();
    //         for (vit = union_r.outer_boundary().vertices_begin();
    //             vit != union_r.outer_boundary().vertices_end(); ++vit) {
    //             _container.emplace_back(vit->x(), vit->y(), 0.0);
    //         }
    //         return true;
    //     } else {
    //         std::string err_msg = "P and Q are disjoint and their union is trivial";
    //         LogMessage log_msg;
    //         log_msg.set_msg(err_msg);
    //         Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
    //     }

    //     return false;
    // }

    bool has_overlap(const Polygon<Traits_P>& polygon) const {
        if (container().size() <= 0 || polygon.container().size() <= 0){
            std::string err_msg = "input param error in polgon overlap test";
            LogMessage log_msg;
            log_msg.set_msg(err_msg);
            Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
            return false;
        }

        std::vector< ::adu::common::math::Vec2d> polygon2d_1_points;
        std::vector< ::adu::common::math::Vec2d> polygon2d_2_points;

        for (auto& polygon_1_point : container()){
            ::adu::common::math::Vec2d polygon2d_1_point(
                polygon_1_point._x, polygon_1_point._y);
            polygon2d_1_points.push_back(polygon2d_1_point);
        }

        for (auto& polygon_2_point : polygon.container()){
            ::adu::common::math::Vec2d polygon2d_2_point(
                polygon_2_point._x, polygon_2_point._y);
            polygon2d_2_points.push_back(polygon2d_2_point);
        }

        ::adu::common::math::Polygon2d polygon2d_1(polygon2d_1_points);
        ::adu::common::math::Polygon2d polygon2d_2(polygon2d_2_points);

        if (polygon2d_1.has_overlap(polygon2d_2)){
            return true;
        }

        return false;
    }

    bool contain(const Line3D& line) {
        if (container().size() <= 0 || line.size() != 2){
            std::string err_msg = "input param error in polgon contain";
            LogMessage log_msg;
            log_msg.set_msg(err_msg);
            Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
            return false;
        }
        std::vector<::adu::common::math::Vec2d> polygon2d_points;
        for (auto& polygon_point : container()){
            ::adu::common::math::Vec2d polygon2d_point(
                            polygon_point._x, polygon_point._y);
            polygon2d_points.push_back(polygon2d_point);
        }

        ::adu::common::math::Polygon2d polygon_2d(polygon2d_points);

        ::adu::common::math::Vec2d segment_start(
                                    line[0]._x, line[0]._y);
        ::adu::common::math::Vec2d segment_end(
                                    line[1]._x, line[1]._y);

        ::adu::common::math::Segment2d line_segment2d(segment_start,
                                                    segment_end);
        if (polygon_2d.is_contain(line_segment2d)) {
            return true;
        }

        return false;
    }

private:
    Container_P _container;
};

struct Trait_P {
    typedef double FT;
    typedef Point3D Point;
};

typedef Polygon<Trait_P> Polygon3D;

struct Trait_P_2 {
    typedef double FT;
    typedef Point2D Point;
};

typedef Polygon<Trait_P_2> Polygon2D;

template<typename Traits>
std::vector<typename Traits::Point> points_from_polygon(const Polygon<Traits>& polygon) {
    std::vector<typename Traits::Point> points(polygon.vertices_begin(),
                                        polygon.vertices_end());
    return points;
}

} // namespace hdmap
} // namespace adu

#endif // BAIDU_ADU_HDMAP_RTK_POLYGON_H