#include "rtk_map_lane_writer.h"

#include "common_util.h"

namespace adu {
namespace hdmap {

double calc_distance(const CommonPbPoint& pt1, const CommonPbPoint& pt2) {
    return sqrt((pt1.x() - pt2.x()) * (pt1.x() - pt2.x())
        + (pt1.y() - pt2.y()) * (pt1.y() - pt2.y())
        + (pt1.z() - pt2.z()) * (pt1.z() - pt2.z()));
}

void calc_offset_pt_in_line(const ::adu::common::hdmap::Point& start_pt,
                            const ::adu::common::hdmap::Point& end_pt,
                            double offset,
                            ::adu::common::hdmap::Point* pt) {
    double line_length = calc_distance(start_pt,end_pt); 
    if (is_zero(line_length)) {
        pt->set_x(start_pt.x());
        pt->set_y(start_pt.y());
    }
    double ratio = offset / line_length;
    pt->set_x((end_pt.x() - start_pt.x()) * ratio + start_pt.x());
    pt->set_y((end_pt.y() - start_pt.y()) * ratio + start_pt.y());
}

double calc_line_segment_heading(
                const ::adu::common::hdmap::LineSegment& segment) {
    const double offset = 1.0;
    double remain_length = offset;
    for (int i = 1; i < segment.point_size(); ++i) {
        double step_length = calc_distance(segment.point(i - 1),
                                           segment.point(i));
        if (step_length > remain_length) {
            ::adu::common::hdmap::Point end_pt;
            calc_offset_pt_in_line(segment.point(i - 1),
                                   segment.point(i),
                                   remain_length,
                                   &end_pt);
            double vec_x = end_pt.x() - segment.point(0).x();
            double vec_y = end_pt.y() - segment.point(0).y();
            if (fabs(vec_x) < 0.00001) {
                if (vec_y > 0) {
                    return M_PI / 2;
                } else {
                    return -M_PI / 2;
                }
            } else {
                double angle = atan(vec_y / vec_x);
                while (angle > M_PI) {
                    angle -= M_PI * 2;
                }
                while (angle < -M_PI) {
                    angle += M_PI * 2;
                }
                return angle;
            }
        }
        remain_length -= step_length;
    }
    return 0;
}

void RTKMapLaneWriter::set_pb_boundary_edge(std::vector<Point3D>& pts,
                                ::adu::common::hdmap::BoundaryEdge_Type type,
                                ::adu::common::hdmap::BoundaryEdge* edge) {
    auto edge_segment = edge->mutable_curve()->add_segment();
    for (auto& edge_pt : pts) {
        auto pt = edge_segment->mutable_line_segment()->add_point();
        pt->set_x(edge_pt._x);
        pt->set_y(edge_pt._y);
        pt->set_z(edge_pt._z);
    }
    edge->set_type(type);
}

void RTKMapLaneWriter::set_pb_road(const RTKMap& hdmap_data,
                                RoadTable& road_table) {
    for (auto &data_road_pair : hdmap_data._roads) { 
        RoadPtr common_pb_road(new ::adu::common::hdmap::Road());
        auto& data_road = data_road_pair.second;
        std::string road_id = data_road._id;
        common_pb_road->mutable_id()->set_id(data_road._id);

        size_t section_size = data_road._sections.size();
        if (section_size <= 0) {
            std::string err_msg = "road " + data_road_pair.first + " with no section";
            LogMessage log_msg;
            log_msg.set_msg(err_msg);
            log_msg.add_type(ROAD);
            log_msg.add_id(data_road_pair.first);
            Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        }
        for (size_t i = 0; i < data_road._sections.size(); ++i) {
            auto& section = data_road._sections[i];
            auto common_pb_section = common_pb_road->add_section();
            // left border
            auto left_edge = common_pb_section->mutable_boundary()->
                mutable_outer_polygon()->add_edge();
            auto left_edge_pts = points_from_line(section._boundary._left_boundary);
            set_pb_boundary_edge(left_edge_pts,
                ::adu::common::hdmap::BoundaryEdge::LEFT_BOUNDARY,
                left_edge);
            // right border
            auto right_edge = common_pb_section->mutable_boundary()->
                mutable_outer_polygon()->add_edge();
            auto right_edge_pts = points_from_line(section._boundary._right_boundary);
            std::reverse(right_edge_pts.begin(), right_edge_pts.end());
            set_pb_boundary_edge(right_edge_pts,
                ::adu::common::hdmap::BoundaryEdge::RIGHT_BOUNDARY,
                right_edge);
            // hole
            for (auto& boundary_hole : section._boundary._holes) {
                auto hole = common_pb_section->mutable_boundary()->add_hole();
                auto hole_edge = hole->add_edge();
                auto hole_pts = points_from_polygon(boundary_hole);
                set_pb_boundary_edge(hole_pts,
                    ::adu::common::hdmap::BoundaryEdge::NORMAL,
                    hole_edge);
            }

            for (auto& lane : section._lanes) {
                common_pb_section->add_lane_id()->set_id(lane._id);
            }

            common_pb_section->mutable_id()->set_id(std::to_string(i + 1));
        } // end section loop

        road_table.insert(RoadTable::value_type(road_id, common_pb_road));
    } // end road
}

void RTKMapLaneWriter::set_pb_lane(const RTKMap& hdmap_data, 
                                LaneTable& lane_table){
    for (auto &data_road_pair : hdmap_data._roads) {
        auto& data_road = data_road_pair.second;
        size_t section_size = data_road._sections.size();

        for (size_t section_index = 0; section_index < section_size; ++section_index){
            auto& section = data_road._sections[section_index];

            for (size_t lane_index = 0; lane_index < section._lanes.size(); ++lane_index) {
                auto& data_lane = section._lanes[lane_index];

                LanePtr common_pb_lane(new ::adu::common::hdmap::Lane());

                std::string unique_lane_id = data_lane._id;
                common_pb_lane->mutable_id()->set_id(unique_lane_id);

                // only support max speed now
                if (data_lane._max_speed > 0) {
                    common_pb_lane->set_speed_limit(data_lane._max_speed);
                }

                common_pb_lane->set_turn(get_lane_turn(data_lane._turn_type));
                common_pb_lane->set_type(get_lane_type(data_lane._lane_type));
                common_pb_lane->set_direction(
                                get_lane_direction(data_lane._direction));

                calc_lane_boundary(data_lane, common_pb_lane);

                set_boundary_type(&data_lane, common_pb_lane);
                set_lane_neighbor(section, lane_index, common_pb_lane);

                calc_lane_central_line(data_lane, common_pb_lane);

                calc_lane_heading(common_pb_lane);

                add_lane_connections(data_lane, common_pb_lane);

                add_lane_width(data_lane, common_pb_lane);

                lane_table.insert(LaneTable::value_type(unique_lane_id, common_pb_lane));
            }//end lane loop
        }//end section loop
    }// end road
}

void RTKMapLaneWriter::calc_lane_boundary(const DataLane& data_lane, LanePtr& lane) {

    ::adu::common::hdmap::CurveSegment *left_segment = NULL;
    if (lane->mutable_left_boundary()->mutable_curve()->segment_size() == 0) {
        left_segment = lane->mutable_left_boundary()->mutable_curve()->add_segment();
    } else {
        left_segment = lane->mutable_left_boundary()->mutable_curve()->mutable_segment(0);
    }

    if (data_lane._left_border._border.size() < 2) {
        std::string err_msg = "lane " + data_lane._id  + "left border has too few points";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        log_msg.add_type(LANE);
        log_msg.add_id(data_lane._id);
        log_msg.add_pts(points_from_line(data_lane._left_border._border));
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);

        return;
    }

    calc_lane_left_boundary(data_lane._left_border, left_segment);
    ::adu::common::hdmap::LaneBoundary::Type left_type;
    get_line_type(data_lane._left_border._type, left_type);
    lane->mutable_left_boundary()->set_type(left_type);

    ::adu::common::hdmap::CurveSegment *right_segment = NULL;
    if (lane->mutable_right_boundary()->mutable_curve()->segment_size() == 0) {
        right_segment = lane->mutable_right_boundary()->mutable_curve()->add_segment();
    } else {
        right_segment = lane->mutable_right_boundary()->mutable_curve()->mutable_segment(0);
    }

    if (data_lane._right_border._border.size() < 2) {
        std::string err_msg = "lane " + data_lane._id + "right border has too few points";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        log_msg.add_type(LANE);
        log_msg.add_id(data_lane._id);
        log_msg.add_pts(points_from_line(data_lane._right_border._border));
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
    }

    calc_lane_right_boundary(data_lane._right_border, right_segment);

    ::adu::common::hdmap::LaneBoundary::Type right_type;
    get_line_type(data_lane._right_border._type, right_type);
    lane->mutable_right_boundary()->set_type(right_type);

    double left_boundary_length = calc_lane_length(
                lane->left_boundary().curve().segment(0).line_segment());
    lane->mutable_left_boundary()->set_length(left_boundary_length);
    ::adu::common::hdmap::CurveSegment *curve_segment =
        lane->mutable_left_boundary()->mutable_curve()->mutable_segment(0);
    curve_segment->set_s(0.0);
    curve_segment->mutable_start_position()->set_x(data_lane._left_border._border[0]._x);
    curve_segment->mutable_start_position()->set_y(data_lane._left_border._border[0]._y);
    curve_segment->set_length(left_boundary_length);
    lane->mutable_left_boundary()->set_virtual_(data_lane._left_border._artificial);

    double right_boundary_length = calc_lane_length(
        lane->right_boundary().curve().segment(0).line_segment());
    lane->mutable_right_boundary()->set_length(right_boundary_length);
    curve_segment = lane->mutable_right_boundary()->mutable_curve()->mutable_segment(0);
    curve_segment->set_s(0.0);
    curve_segment->mutable_start_position()->set_x(data_lane._right_border._border[0]._x);
    curve_segment->mutable_start_position()->set_y(data_lane._right_border._border[0]._y);
    curve_segment->set_length(right_boundary_length);
    lane->mutable_right_boundary()->set_virtual_(data_lane._right_border._artificial);
}

void RTKMapLaneWriter::calc_lane_left_boundary(const DataLaneBorder& lane_left_border,
                            ::adu::common::hdmap::CurveSegment *lane_left_boundary) {
    for (auto& left_border_pt : lane_left_border._border.container()){
        ::adu::common::hdmap::Point* pt = lane_left_boundary->mutable_line_segment()->add_point();
        pt->set_x(left_border_pt._x);
        pt->set_y(left_border_pt._y);
        pt->set_z(left_border_pt._z);
    }
}

void RTKMapLaneWriter::calc_lane_right_boundary(const DataLaneBorder& lane_right_border,
    ::adu::common::hdmap::CurveSegment *lane_right_boundary) {

    for (auto& right_border_pt : lane_right_border._border.container()){
        ::adu::common::hdmap::Point* pt = lane_right_boundary->mutable_line_segment()->add_point();
        pt->set_x(right_border_pt._x);
        pt->set_y(right_border_pt._y);
        pt->set_z(right_border_pt._z);
    }
}

void RTKMapLaneWriter::calc_lane_central_line(const DataLane& data_lane, LanePtr &lane) {
    using ::adu::common::hdmap::LineSegment;

    if (lane->left_boundary().curve().segment_size() <= 0) {
        std::string err_msg = "lane left boundary has no segment";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        log_msg.add_type(LANE);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
    }
    const LineSegment &left_boundary =
        lane->left_boundary().curve().segment(0).line_segment();

    if (lane->right_boundary().curve().segment_size() <= 0) {
        std::string err_msg = "lane right boundary has no segment";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        log_msg.add_type(LANE);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
    }
    const LineSegment &right_boundary =
        lane->right_boundary().curve().segment(0).line_segment();

    if (left_boundary.point_size() != right_boundary.point_size()) {
        std::string err_msg = "lane left and right boundary has different point size";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        log_msg.add_type(LANE);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
    }

    if (left_boundary.point_size() < 2) {
        std::string err_msg = "lane left_boundary has too few points";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        log_msg.add_type(LANE);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
    }

    if (right_boundary.point_size() < 2) {
        std::string err_msg = "lane right_boundary has too few points";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        log_msg.add_type(LANE);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
    }

    if (data_lane._center_line.size() != right_boundary.point_size()) {
        std::string err_msg = "lane center and right boundary has different points size";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        log_msg.add_type(LANE);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
    }

    auto segment =  lane->mutable_central_curve()->add_segment();

    for (int i = 0; i < data_lane._center_line.size(); ++i) {
        auto line_pt = segment->mutable_line_segment()->add_point();
        line_pt->set_x(data_lane._center_line[i].x());
        line_pt->set_y(data_lane._center_line[i].y());
        line_pt->set_z(data_lane._center_line[i].z());
    }

    segment->set_s(0.0);
    segment->mutable_start_position()->set_x(data_lane._center_line[0].x());
    segment->mutable_start_position()->set_y(data_lane._center_line[0].y());
    segment->mutable_start_position()->set_z(data_lane._center_line[0].z());

    lane->set_length(calc_lane_length(lane->central_curve().segment(0).line_segment()));
    lane->mutable_central_curve()->mutable_segment(0)->set_length(lane->length());
}

double RTKMapLaneWriter::calc_lane_length(
    const ::adu::common::hdmap::LineSegment &lane_segment) {
    double lane_length = 0;
    for (int i = 0; i < lane_segment.point_size() - 1; ++i) {
        lane_length += calc_distance(lane_segment.point(i), lane_segment.point(i + 1));
    }
    return lane_length;
}

::adu::common::hdmap::Lane::LaneTurn RTKMapLaneWriter::get_lane_turn(Lane_TurnType turn_type) {
    switch (turn_type) {
        case LANE_TURNTYPE_LEFT_TURN:
            return ::adu::common::hdmap::Lane::LEFT_TURN;
        case LANE_TURNTYPE_RIGHT_TURN:
            return ::adu::common::hdmap::Lane::RIGHT_TURN;
        case LANE_TURNTYPE_U_TURN:
            return ::adu::common::hdmap::Lane::U_TURN;
        case LANE_TURNTYPE_NO_TURN:
            return ::adu::common::hdmap::Lane::NO_TURN;
        default: {
            std::string err_msg = "Not support lane turn type:" + std::to_string((int)turn_type);
            LogMessage log_msg;
            log_msg.set_msg(err_msg);
            Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        }

        return ::adu::common::hdmap::Lane::NO_TURN;
    }
}

::adu::common::hdmap::Lane::LaneType RTKMapLaneWriter::get_lane_type(Lane_LaneType lane_type) {
    int type = (int)lane_type;
    if (type <= 20) {
        return (::adu::common::hdmap::Lane::LaneType)type;
    } else {
        std::string err_msg = "Not support lane type:"
            + std::to_string((int)type);
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);

        return ::adu::common::hdmap::Lane::NONE;
    }
}

::adu::common::hdmap::Lane::LaneDirection
RTKMapLaneWriter::get_lane_direction(LaneDirection lane_direction) {
    switch (lane_direction) {
        case LANE_DIRECTION_FORWARD:
            return ::adu::common::hdmap::Lane::FORWARD;
        case LANE_DIRECTION_BACKWARD:
            return ::adu::common::hdmap::Lane::BACKWARD;
        case LANE_DIRECTION_BIDIRECTION:
            return ::adu::common::hdmap::Lane::BIDIRECTION;
        default: {
            std::string err_msg = "Not support lane direction type:"
                    + std::to_string((int)lane_direction);
            LogMessage log_msg;
            log_msg.set_msg(err_msg);
            Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        }

        return ::adu::common::hdmap::Lane::FORWARD;
    }
}

void RTKMapLaneWriter::calc_lane_heading(LanePtr& lane) {
    const ::adu::common::hdmap::LineSegment &left_boundary =
        lane->left_boundary().curve().segment(0).line_segment();
    double left_boundary_heading = calc_line_segment_heading(left_boundary);
    ::adu::common::hdmap::CurveSegment *curve_segment = 
                            lane->mutable_left_boundary()->mutable_curve()->mutable_segment(0);
    curve_segment->set_heading(left_boundary_heading);

    const ::adu::common::hdmap::LineSegment &central_line =
        lane->central_curve().segment(0).line_segment();
    double central_line_heading = calc_line_segment_heading(central_line);
    curve_segment = lane->mutable_central_curve()->mutable_segment(0);
    curve_segment->set_heading(central_line_heading);

    const ::adu::common::hdmap::LineSegment &right_boundary =
        lane->right_boundary().curve().segment(0).line_segment();
    double right_boundary_heading = calc_line_segment_heading(right_boundary);
    curve_segment = lane->mutable_right_boundary()->mutable_curve()->mutable_segment(0);
    curve_segment->set_heading(right_boundary_heading);
}

void RTKMapLaneWriter::add_lane_connections(const DataLane& data_lane, 
                                            LanePtr& common_pb_lane){
    for (auto& predecessor : data_lane._predessors) {
        common_pb_lane->add_predecessor_id()->set_id(predecessor);
    }

    for (auto& successor : data_lane._successors) {
        common_pb_lane->add_successor_id()->set_id(successor);
    }
}

void RTKMapLaneWriter::get_line_type(
    const RoadMarkType line_type,
    ::adu::common::hdmap::LaneBoundary::Type &type) {
    switch (line_type) {
        case ROADMARKTYPE_UNKNOWN:
            type = ::adu::common::hdmap::LaneBoundary::UNKNOWN;
            break;
        case ROADMARKTYPE_CURB:
            type = ::adu::common::hdmap::LaneBoundary::CURB;
            break;
        case ROADMARKTYPE_DOTTED_YELLOW:
        case ROADMARKTYPE_SOLID_DOTTED_YELLOW:
        case ROADMARKTYPE_DOTTED_DOTTED_YELLOW:
            type = ::adu::common::hdmap::LaneBoundary::DOTTED_YELLOW;
            break;
        case ROADMARKTYPE_DOTTED_WHITE:
        case ROADMARKTYPE_SOLID_DOTTED_WHITE:
        case ROADMARKTYPE_DOTTED_DOTTED_WHITE:
            type = ::adu::common::hdmap::LaneBoundary::DOTTED_WHITE;
            break;

        case ROADMARKTYPE_SOLID_YELLOW:
        case ROADMARKTYPE_DOTTED_SOLID_YELLOW:
        case ROADMARKTYPE_SOLID_SOLID_YELLOW:
            type = ::adu::common::hdmap::LaneBoundary::SOLID_YELLOW;
            break;
        case ROADMARKTYPE_SOLID_WHITE:
        case ROADMARKTYPE_DOTTED_SOLID_WHITE:
        case ROADMARKTYPE_SOLID_SOLID_WHITE:
            type = ::adu::common::hdmap::LaneBoundary::SOLID_WHITE;
            break;
        default:
            type = ::adu::common::hdmap::LaneBoundary::DOTTED_WHITE;
            std::string err_msg = "undefined road mark type of lane "
                + std::to_string((int)line_type);
            LogMessage log_msg;
            log_msg.set_msg(err_msg);
            Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);

            break;
    }
}

::adu::common::hdmap::LaneBoundaryType::Type
RTKMapLaneWriter::to_boundary_type(const RoadMarkType line_type) {
    ::adu::common::hdmap::LaneBoundaryType::Type boundary_type;
    switch (line_type) {
        case ROADMARKTYPE_UNKNOWN:
            boundary_type = ::adu::common::hdmap::LaneBoundaryType::UNKNOWN;
            break;
        case ROADMARKTYPE_CURB:
            boundary_type = ::adu::common::hdmap::LaneBoundaryType::CURB;
            break;
        case ROADMARKTYPE_DOTTED_YELLOW:
        case ROADMARKTYPE_SOLID_DOTTED_YELLOW:
        case ROADMARKTYPE_DOTTED_DOTTED_YELLOW:
            boundary_type = ::adu::common::hdmap::LaneBoundaryType::DOTTED_YELLOW;
            break;
        case ROADMARKTYPE_DOTTED_WHITE:
        case ROADMARKTYPE_SOLID_DOTTED_WHITE:
        case ROADMARKTYPE_DOTTED_DOTTED_WHITE:
            boundary_type = ::adu::common::hdmap::LaneBoundaryType::DOTTED_WHITE;
            break;

        case ROADMARKTYPE_SOLID_YELLOW:
        case ROADMARKTYPE_DOTTED_SOLID_YELLOW:
        case ROADMARKTYPE_SOLID_SOLID_YELLOW:
            boundary_type = ::adu::common::hdmap::LaneBoundaryType::SOLID_YELLOW;
            break;
        case ROADMARKTYPE_SOLID_WHITE:
        case ROADMARKTYPE_DOTTED_SOLID_WHITE:
        case ROADMARKTYPE_SOLID_SOLID_WHITE:
            boundary_type = ::adu::common::hdmap::LaneBoundaryType::SOLID_WHITE;
            break;
        default:
            boundary_type = ::adu::common::hdmap::LaneBoundaryType::DOTTED_WHITE;
            std::string err_msg = "undefined road mark type of lane "
                + std::to_string((int)line_type);
            LogMessage log_msg;
            log_msg.set_msg(err_msg);
            Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
            break;
    }

    return boundary_type;
}

class BorderType {
public:
    double _start_s;
    std::vector<::adu::common::hdmap::LaneBoundaryType::Type> _types;
};

void RTKMapLaneWriter::set_boundary_type(const DataLane *lane,
                                        LanePtr& common_pb_lane) {
    std::vector<BorderType> left_border_types;
    std::vector<BorderType> right_border_types;

    BorderType left_border_type;
    left_border_type._start_s = 0;
    left_border_type._types.push_back(to_boundary_type(lane->_left_border._type));
    left_border_types.push_back(left_border_type);

    BorderType right_border_type;
    right_border_type._start_s = 0;
    right_border_type._types.push_back(to_boundary_type(lane->_right_border._type));
    right_border_types.push_back(right_border_type);

    for (auto& left_border_type : left_border_types) {
        auto left_boundary_type = common_pb_lane->mutable_left_boundary()
                                ->add_boundary_type();
        left_boundary_type->set_s(left_border_type._start_s);
        for (auto type : left_border_type._types) {
            left_boundary_type->add_types(type);
        }
    }

    for (auto& right_border_type : right_border_types) {
        auto right_boundary_type = common_pb_lane->mutable_right_boundary()
                                    ->add_boundary_type();
        right_boundary_type->set_s(right_border_type._start_s);
        for (auto type : right_border_type._types) {
            right_boundary_type->add_types(type);
        }
    }
}

void RTKMapLaneWriter::set_lane_neighbor(const RoadSection& section,
                                        int index, LanePtr& lane) {
    size_t lane_index = (size_t)index;

    auto& data_lane = section._lanes[lane_index];
    for (auto& left_neighbor_id : data_lane._left_neighbor_lane_ids) {
        lane->add_left_neighbor_forward_lane_id()->set_id(left_neighbor_id);
    }
    for (auto& right_neighbor_id : data_lane._right_neighbor_lane_ids) {
        lane->add_right_neighbor_forward_lane_id()->set_id(right_neighbor_id);
    }
    for (auto& reverse_lane_id : data_lane._left_reverse_neighbor_lane_ids) {
        lane->add_left_neighbor_reverse_lane_id()->set_id(reverse_lane_id);
    }
    for (auto& reverse_lane_id : data_lane._right_reverse_neighbor_lane_ids) {
        lane->add_right_neighbor_reverse_lane_id()->set_id(reverse_lane_id);
    }
}

void RTKMapLaneWriter::calc_lane_width(LanePtr& lane) {
    using ::adu::common::hdmap::LineSegment;
    if (lane->left_boundary().curve().segment_size() < 0) {
        std::string err_msg = "lane left boundary has no curve";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        return;
    }

    if (lane->right_boundary().curve().segment_size() < 0) {
        std::string err_msg = "lane right boundary has no curve.";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        return;
    }

    const LineSegment &left_boundary =
        lane->left_boundary().curve().segment(0).line_segment();

    const LineSegment &right_boundary =
        lane->right_boundary().curve().segment(0).line_segment();

    const LineSegment &central_line =
        lane->central_curve().segment(0).line_segment();

    if (left_boundary.point_size() != right_boundary.point_size()) {
        std::string err_msg = "lane left boundary size is not equal to right boundary";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        return;
    }

    if (left_boundary.point_size() != central_line.point_size()) {
        std::string err_msg = "lane left boundary size is not equal to central line";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        return;        
    }

    double total_width = 0;
    double left_width = 0;
    double right_width = 0;
    double s_offset = 0.0;
    for (int i = 0; i < central_line.point_size(); ++i) {
        left_width = calc_distance(left_boundary.point(i), central_line.point(i));
        right_width = calc_distance(right_boundary.point(i), central_line.point(i));
        total_width += left_width + right_width;
        if (i != 0) {
            s_offset += calc_distance(central_line.point(i), central_line.point(i - 1));
        }

        auto left_sample = lane->add_left_sample();
        left_sample->set_width(left_width);
        left_sample->set_s(s_offset);
        auto right_sample = lane->add_right_sample();
        right_sample->set_width(right_width);
        right_sample->set_s(s_offset);
    }
    lane->set_width(total_width / central_line.point_size());
}

void RTKMapLaneWriter::add_lane_width(const DataLane& data_lane,
                                            LanePtr& lane) {
    
    if (data_lane._left_dis.size() != data_lane._right_dis.size()) {
        std::string err_msg = "lane left boundary size is not equal to right size";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        log_msg.add_id(data_lane._id);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        return;
    }

    if (data_lane._left_dis.size() != data_lane._center_line.size()) {
        std::string err_msg = "lane left boundary size is not equal to center size";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        log_msg.add_id(data_lane._id);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        return;
    }

    if (data_lane._left_dis.size() != data_lane._left_border._border.size()) {
        std::string err_msg = "lane left boundary size is not equal to left border size";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        log_msg.add_id(data_lane._id);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        return;       
    }

    if (data_lane._left_road_dis.size() != data_lane._right_road_dis.size()) {
        std::string err_msg = "lane left road boundary size is not equal to right";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        log_msg.add_id(data_lane._id);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        return;        
    }

    if (data_lane._left_road_dis.size() != data_lane._left_dis.size()) {
        std::string err_msg = "lane left road boundary size is not equal to left";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        log_msg.add_id(data_lane._id);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        return;        
    }

    double total_width = 0.0;
    for (size_t i = 0; i < data_lane._center_line.size(); ++i) {
        auto left_sample = lane->add_left_sample();
        double left_width = data_lane._left_dis[i].width;
        left_sample->set_width(left_width);
        left_sample->set_s(data_lane._left_dis[i].s);
        auto right_sample = lane->add_right_sample();
        double right_width = data_lane._right_dis[i].width;
        right_sample->set_width(right_width);
        right_sample->set_s(data_lane._right_dis[i].s);

        total_width += left_width + right_width;

        auto left_road_sample = lane->add_left_road_sample();
        left_road_sample->set_width(data_lane._left_road_dis[i].width);
        left_road_sample->set_s(data_lane._left_road_dis[i].s);
        auto right_road_sample = lane->add_right_road_sample();
        right_road_sample->set_width(data_lane._right_road_dis[i].width);
        right_road_sample->set_s(data_lane._right_road_dis[i].s);
    }

    lane->set_width(total_width / data_lane._center_line.size());
}

} // namespace hdmap
} // namespace adu
