#include "douglas_peucker_sparse.h"

#include <stack>
#include <limits>
#include <algorithm>

namespace adu {
namespace hdmap {

void DouglasPeucker::douglas_peucker(const std::vector<Point3D>& input,
                    std::vector<Point3D>& output,
                    const double tolerance) {
    if (input.size() < 3) {
        std::copy(input.begin(), input.end(), std::back_inserter(output));
        return;
    }

    std::vector<bool> is_retains(input.size(), false);
    std::stack<StartEnd> start_ends;
    start_ends.emplace(0, input.size() - 1);
    while (!start_ends.empty()) {
        auto start_end = start_ends.top();
        start_ends.pop();
        
        double max_dis = std::numeric_limits<double>::min();
        size_t max_dis_index = 0;
        for (size_t i = start_end.l_index + 1; i < start_end.r_index; i++) {
            double dis = distance_pt_to_line(input, i, start_end.l_index, start_end.r_index);
            if (dis > max_dis) {
                max_dis = dis;
                max_dis_index = i;
            }
        }

        if (max_dis > tolerance) {
            if (max_dis_index - start_end.l_index > 0) {
                start_ends.emplace(start_end.l_index, max_dis_index);
            }
            
            if (start_end.r_index - max_dis_index - 1 > 0 ) {
                start_ends.emplace(max_dis_index, start_end.r_index);
            }
        } else {
            is_retains[start_end.l_index] = true;
            is_retains[start_end.r_index] = true;
        }
    }

    for (size_t i = 0; i < is_retains.size(); i++) {
        if (is_retains[i]) {
            output.push_back(input[i]);
        }
    }
}
double DouglasPeucker::distance_pt_to_line(const std::vector<Point3D>& input,
                        size_t t_index, const size_t s_index,
                        const size_t e_index) {
    if (input[s_index].distance_to(input[e_index]) < DB_EPSINON) {
        return input[t_index].distance_to(input[e_index]);
    }
    Point3D a = input[e_index] - input[s_index];
    Point3D b = input[t_index] - input[s_index];
    return std::abs((a.x() * b.y() - b.x() * a.y()) / std::sqrt(a.x() * a.x() + a.y() * a.y()));
}

} // namespace hdmap
} // namespace adu
