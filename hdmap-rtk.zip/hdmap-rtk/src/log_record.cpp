#include "log_record.h"

#include <boost/assign/list_of.hpp>
#include <array>
#include <algorithm>
#include "common_util.h"

namespace adu {
namespace hdmap {

const std::array<char, 5> filter_json_char = {':', '\r', '\n'};

std::string filter_invalid_json_char(const std::string& raw) {
    std::string filterd_string = raw;
    for (size_t i = 0; i < filterd_string.size(); ++i) {
        auto find_itr = std::find(filter_json_char.begin(), 
                        filter_json_char.end(), filterd_string[i]);
        if (find_itr != filter_json_char.end()) {
            filterd_string[i] = ' ';
        }
    }
    return filterd_string;
}

} // namespace hdmap
} // namespace adu
