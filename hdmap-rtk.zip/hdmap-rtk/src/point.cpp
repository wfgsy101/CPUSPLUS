#include "point.h"

namespace adu {
namespace hdmap {

const std::string Point3D::to_string() const {
    return "(x:" + std::to_string(_x) + " y:" 
        + std::to_string(_y) + " z:" + 
        std::to_string(_z) + ")";
}

const std::string Point2D::to_string() const {
    return "(x:" + std::to_string(_x) + " y:" 
            + std::to_string(_y) + ")";
}

} // namespace hdmap
} // namespace adu