#include "rtk_map_writer.h"

#include <fstream>
#include "map.pb.h"
#include "rtk_map_writer_define.h"
#include "rtk_map_lane_writer.h"
#include "common_util.h"

namespace adu {
namespace hdmap {

bool RTKMapWriter::write(const std::string& output_filename, const RTKMap& hdmap_data) {
    CommonPbMap common_hdmap_data;
    // header
    CommonPbHeader *hdmap_header = common_hdmap_data.mutable_header();
    set_pb_header(hdmap_data, hdmap_header);

    // road
    RoadTable road_table;
    set_pb_road(hdmap_data, road_table);

    // lane
    LaneTable lane_table;
    set_pb_lane(hdmap_data, lane_table);

    add_roads(road_table, common_hdmap_data);
    add_lanes(lane_table, common_hdmap_data);

    // std::cout << common_hdmap_data.DebugString() << std::endl;

    std::fstream output(output_filename,
                        std::ios::out | std::ios::trunc | std::ios::binary);
    if (!output) {
        std::string err_msg = "Fail to Open File For write " + output_filename;
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        return false;
    }

    if (!common_hdmap_data.SerializeToOstream(&output)) {
        std::string err_msg = "Fail to serialization Pb Data";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        return false;
    }

    return true;
}

bool RTKMapWriter::set_pb_header(const RTKMap &hdmap_data, CommonPbHeader *header) {
    const auto& data_header = hdmap_data._header;
    if (!data_header.data_version.empty()) {
        header->set_version(data_header.data_version);
    } else {
        std::string err_msg = "empty data version";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
    }

    if (!data_header.data_date.empty()) {
        header->set_date(data_header.data_date);
    } else {
        std::string err_msg = "empty data date";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
    }

    if (!data_header.data_district.empty()) {
        header->set_district(data_header.data_district);
    } else {
        std::string err_msg = "empty data district";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
    }

    return true;
}

void RTKMapWriter::set_pb_road(const RTKMap& hdmap_data, RoadTable& road_table) {
    Singleton<RTKMapLaneWriter>::instance()->set_pb_road(hdmap_data, road_table);
}

void RTKMapWriter::set_pb_lane(const RTKMap& hdmap_data, LaneTable& lane_table) {
    Singleton<RTKMapLaneWriter>::instance()->set_pb_lane(hdmap_data, lane_table);
}

void RTKMapWriter::add_roads(const RoadTable& road_table, 
                            CommonPbMap& common_pb_map) {
    RoadTable::const_iterator i = road_table.begin();
    while (i != road_table.end()) {
        *(common_pb_map.add_road()) = *(i->second);
        ++i;
    }
}

void RTKMapWriter::add_lanes(const LaneTable &lane_table, 
                            CommonPbMap& common_pb_map) {
    LaneTable::const_iterator i = lane_table.begin();
    while (i != lane_table.end()) {
        *(common_pb_map.add_lane()) = *(i->second);
        ++i;
    }
}

} // namespace hdmap
} // namespace adu