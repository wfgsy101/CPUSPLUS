#include "rtk_map_processor.h"

#include <fstream>
#include <string>
#include <ctime>

#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>

#include "log_record.h"
#include "common_util.h"
#include "douglas_peucker_sparse.h"

namespace adu {
namespace hdmap {

bool RTKMapProcessor::process(const std::string& filename, RTKMap* map) {
   
    std::vector<Point3D> rtk_points;
    if (!load_trajectory(filename, rtk_points)) {
            std::string err_msg = "fail to load trajectory";
            LogMessage log_msg;
            log_msg.set_msg(err_msg);
            Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
            return false;
    }

    DouglasPeucker point_sparser;
    std::vector<Point3D> rtk_sparse_points;
    point_sparser.douglas_peucker(rtk_points, rtk_sparse_points, 0.1);
    if (rtk_sparse_points.size() < 2) {
            std::string err_msg = "trajectory after sparse has too few points";
            LogMessage log_msg;
            log_msg.set_msg(err_msg);
            Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
            return false;
    }

    double total_len = 0.0;
    for (size_t i = 1; i < rtk_sparse_points.size(); i++) {
        total_len += rtk_sparse_points[i].distance_to(rtk_sparse_points[i - 1]);
    }

    std::vector<Point3D> inter_points;
    const size_t segment_size = 7;
    const double step_len = total_len / segment_size;
    double  segment_len = 0.0;
    for (size_t i = 1; i < rtk_sparse_points.size(); i++) {
        segment_len = rtk_sparse_points[i].distance_to(rtk_sparse_points[i - 1]);
        size_t step_size = (size_t)(segment_len / step_len) + 1;
        inter_points.push_back(rtk_sparse_points[i - 1]);
        Point3D unit_vec = (rtk_sparse_points[i] - rtk_sparse_points[i - 1]) / segment_len;
        for (size_t j = 1; j < step_size; j++) {
            inter_points.push_back(rtk_sparse_points[i - 1]
                + unit_vec * j * segment_len / step_size);
        }
    }
    inter_points.push_back(rtk_sparse_points.back());

    return generate_map(inter_points, map);
}

void RTKMapProcessor::set_lane_width(const double width) {
    if (width > 0) {
        _lane_width = width;
    }
}

bool RTKMapProcessor::load_trajectory(const std::string& filename,
                                    std::vector<Point3D>& rtk_points) {
    if (filename.empty()) {
        std::string err_msg = "bad param, empty filename";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        return false;
    }

    std::fstream fin(filename.c_str());
    if (!fin) {
        std::string err_msg = "fail to open " + filename;
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        return false;
    }

    std::string line;
    getline(fin, line);
    getline(fin, line);
    while (getline(fin, line)) {
        std::vector<std::string> split_vec;
        boost::split(split_vec, line, boost::is_any_of(","));
        if (split_vec.size() < 3) {
            std::string err_msg = "fail to split rtk trajectory";
            LogMessage log_msg;
            log_msg.set_msg(err_msg);
            Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
            continue;
        }

        Point3D rtk_point;
        boost::trim(split_vec[0]);
        rtk_point.set_x(boost::lexical_cast<double>(split_vec[0]));

        boost::trim(split_vec[1]);
        rtk_point.set_y(boost::lexical_cast<double>(split_vec[1]));
        rtk_point.set_z(0.0);

        rtk_points.push_back(rtk_point);
    }

    return true;
}

bool RTKMapProcessor::generate_map(const std::vector<Point3D>& rtk_sparse_points, RTKMap* map) {

    if (rtk_sparse_points.size() < 2) {
        std::string err_msg = "trajectory after sparse has too few points";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        return false;
    }

    std::vector<Point3D> origin_left_border;
    std::vector<Point3D> origin_right_border;

    const double half_lane_width = _lane_width / 2.0;

    for (size_t i = 0; i < rtk_sparse_points.size(); i++) {
        Point2D direction_vec;
        if (i == 0) {
            Point3D diff_vec = rtk_sparse_points[i + 1] - rtk_sparse_points[i];
            direction_vec = Point2D{diff_vec.x(), diff_vec.y()};
        } else {
            Point3D diff_vec = rtk_sparse_points[i] - rtk_sparse_points[i - 1];
            direction_vec = Point2D{diff_vec.x(), diff_vec.y()};
        }

        Point2D unit_direction = direction_vec / hypot(direction_vec.x(), direction_vec.y());

        origin_left_border.push_back(
            rtk_sparse_points[i] + Point3D{-half_lane_width * unit_direction.y(),
            half_lane_width * unit_direction.x(), 0.0});
        origin_right_border.push_back(
            rtk_sparse_points[i] + Point3D{half_lane_width * unit_direction.y(),
            -half_lane_width * unit_direction.x(), 0.0});
    }

    std::vector<Point3D> left_border;
    std::vector<Point3D> right_border;
    smooth_border(origin_left_border, left_border);
    smooth_border(origin_right_border, right_border);
    
    fill_data_struct(left_border, right_border, rtk_sparse_points, map);

    return true;
}

void RTKMapProcessor::split_border(const std::vector<Point3D>& left_border,
                                const std::vector<Point3D>& right_border,
                                const std::vector<Point3D>& center_line,
                                std::vector<std::vector<Point3D>>& left_borders,
                                std::vector<std::vector<Point3D>>& center_lines,
                                std::vector<std::vector<Point3D>>& right_borders) {
    if (left_border.size() != right_border.size()) {
        std::string err_msg = "left border size is not equal to right size";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        return;
    }

    if (left_border.size() != center_line.size()) {
        std::string err_msg = "left border size is not equal to center size";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        return;
    }

    // std::vector<Point3D>& center_line;
    double center_length = 0.0;
    for (size_t i = 0; i < center_line.size(); i++) {
        // center_line.push_back((left_border[i] + right_bordre[i]) / 2.0);
        if (i > 0) {
            center_length += center_line[i].distance_to(center_line[i - 1]);
        }
    }

    const double segment_num = 3.0;
    double segment_step = center_length / segment_num;
    double segment_len = 0.0;
    std::vector<size_t> split_index;
    for (size_t i = 0; i < center_line.size(); i++) {
        if (i > 0) {
            segment_len += center_line[i].distance_to(center_line[i - 1]);
        }
        if (segment_len > segment_step) {
            split_index.push_back(i);
            segment_len = 0;
        }
    }
    split_index.push_back(center_line.size());

    int start_index = 0;
    int end_index = 0;
    for (size_t j = 0; j < split_index.size(); j++) {
        end_index = split_index[j];
        std::vector<Point3D> tmp_left_border;
        std::vector<Point3D> tmp_right_border;
        std::vector<Point3D> tmp_center_line;
        for (int i = start_index; i < end_index; i++) {
            tmp_left_border.push_back(left_border[i]);
            tmp_right_border.push_back(right_border[i]);
            tmp_center_line.push_back(center_line[i]);
        }
        left_borders.push_back(tmp_left_border);
        right_borders.push_back(tmp_right_border);
        center_lines.push_back(tmp_center_line);

        start_index = end_index - 1;
    }
}

void RTKMapProcessor::fill_data_struct(const std::vector<Point3D>& left_border,
                    const std::vector<Point3D>& right_border,
                    const std::vector<Point3D>& center_line, RTKMap* map) {
    
    std::vector<std::vector<Point3D>> left_borders;
    std::vector<std::vector<Point3D>> center_lines;
    std::vector<std::vector<Point3D>> right_borders;
    split_border(left_border, right_border, center_line, left_borders, center_lines, right_borders);

    if (left_borders.size() != right_borders.size() || center_lines.size() != left_borders.size()) {
        std::string err_msg = "left borders size is not equal to rights size";
        LogMessage log_msg;
        log_msg.set_msg(err_msg);
        Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        return;
    }

    map->_header.data_version = "1.5";
    map->_header.data_date = std::to_string(std::time(0));
    map->_header.data_district = "rtk_map";
    map->_header.map_id = "rtk_map";

    for (size_t i = 0; i < center_lines.size(); i++) {
        std::string road_id = std::to_string(i + 1);

        DataLane rtk_lane;
        rtk_lane._id = road_id + "_1_1";
        rtk_lane._max_speed = 20.0 / 3.6;
        rtk_lane._min_speed = 20.0 / 3.6;
        rtk_lane._lane_type = LANE_LANETYPE_CITY_DRIVING;
        rtk_lane._turn_type = LANE_TURNTYPE_NO_TURN;
        rtk_lane._direction = LANE_DIRECTION_FORWARD;
        rtk_lane._center_line.insert(rtk_lane._center_line.vertices_end(), center_lines[i].begin(),
                                center_lines[i].end());
        rtk_lane._left_border._border.insert(rtk_lane._left_border._border.vertices_end(), 
                                left_borders[i].begin(),
                                left_borders[i].end());
        rtk_lane._left_border._type = ROADMARKTYPE_SOLID_WHITE;
        rtk_lane._right_border._border.insert(rtk_lane._right_border._border.vertices_end(),
                                right_borders[i].begin(),
                                right_borders[i].end());
        rtk_lane._right_border._type = ROADMARKTYPE_SOLID_WHITE;
        
        if (i > 0) {
            std::string pre_road_id = std::to_string(i); 
            rtk_lane._predessors.insert(pre_road_id + "_1_1");
        }

        if (i + 1 <  center_lines.size()) {
            std::string suc_road_id = std::to_string(i + 2); 
            rtk_lane._successors.insert(suc_road_id + "_1_1");
        }

        double s_offset = 0.0;
        for (size_t j = 0; j < center_lines[i].size(); ++j) {
            if (j != 0) {
                s_offset += center_lines[i][j].distance_to(center_lines[i][j - 1]);
            }
            LaneSampleAssociation left_dis;
            left_dis.s = s_offset;
            left_dis.width = center_lines[i][j].distance_to(left_borders[i][j]);
            rtk_lane._left_dis.push_back(left_dis);
            rtk_lane._left_road_dis.push_back(left_dis);

            LaneSampleAssociation right_dis;
            right_dis.s = s_offset;
            right_dis.width = center_lines[i][j].distance_to(right_borders[i][j]);
            rtk_lane._right_dis.push_back(right_dis);
            rtk_lane._right_road_dis.push_back(right_dis);
        }

        RoadSection rtk_road_section;
        rtk_road_section._id = "1";
        rtk_road_section._lanes.push_back(rtk_lane);
        rtk_road_section._boundary._left_boundary.insert(
                            rtk_road_section._boundary._left_boundary.vertices_end(),
                            left_borders[i].begin(),
                            left_borders[i].end());
        rtk_road_section._boundary._right_boundary.insert(
                            rtk_road_section._boundary._right_boundary.vertices_end(),
                            right_borders[i].begin(),
                            right_borders[i].end());

        Road rtk_road;
        rtk_road._id = road_id;
        rtk_road._sections.push_back(rtk_road_section);

        if (map->_roads.count(rtk_road._id) > 0) {
            std::string err_msg = "duplicate road id found";
            LogMessage log_msg;
            log_msg.set_msg(err_msg);
            Singleton<LogRecord<LogMessage>>::instance()->record_error(log_msg);
        }

        map->_roads[rtk_road._id] = rtk_road;
    }
}

void RTKMapProcessor::smooth_border(const std::vector<Point3D>& origin_border,
                                    std::vector<Point3D>& border) {
    int escape_cnt = 0;
    border.push_back(origin_border[0]);
    border.push_back(origin_border[1]);
    size_t i = 1;
    size_t j = i + 1;
    size_t k = 0;
    while (i < origin_border.size() && j < origin_border.size()) {
        Point3D a = origin_border[i] - origin_border[k];
        Point3D b = origin_border[j] - origin_border[i];

        double dot_value = a.x() * b.x() + a.y() * b.y();
        if (dot_value <= 0) {
            escape_cnt++;
            j++;
        } else {
            if (escape_cnt > 0) {
                Point3D diff_vec = origin_border[j] - origin_border[i];
                Point2D direction_vec = Point2D{diff_vec.x(), diff_vec.y()};
                double diff_length = hypot(direction_vec.x(), direction_vec.y());
                Point2D unit_direction = direction_vec / diff_length;
                for (size_t m = 1; m <= escape_cnt; m++) {
                    border.push_back(origin_border[i] +
                        Point3D{unit_direction.x() * diff_length * m / (escape_cnt + 1),
                        unit_direction.y() * diff_length * m / (escape_cnt + 1), 0.0});
                }
            }
            border.push_back(origin_border[j]);
            k = i;
            i = j;
            j = i + 1;
            escape_cnt = 0;
        }
    }
    if (escape_cnt > 0) {
        Point3D diff_vec = origin_border[i] - origin_border[k];
        Point2D direction_vec = Point2D{diff_vec.x(), diff_vec.y()};
        double diff_length = hypot(direction_vec.x(), direction_vec.y());
        Point2D unit_direction = direction_vec / diff_length;
        border.pop_back();
        for (size_t m = 1; m <= escape_cnt; m++) {
            border.push_back(origin_border[k] +
                Point3D{unit_direction.x() * diff_length * m / (escape_cnt + 1),
                unit_direction.y() * diff_length * m / (escape_cnt + 1), 0.0});
        }
        border.push_back(origin_border[i]);
    }
}

} // namespace hdmap
} // namespace adu
