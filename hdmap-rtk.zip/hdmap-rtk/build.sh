#!/bin/bash

SCRIPT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK_ROOT=${SCRIPT_ROOT}/../../..

ADU_3RD_DIR=${WORK_ROOT}/baidu/adu-3rd
protoc=${ADU_3RD_DIR}/protobuf/bin/protoc

build_dependency="none"

if [ "$1"x == "-a"x ];then
    build_dependency="build-all"
fi

function check_dependency_common() {
    echo "checking dependency common..."
    if [ "$build_dependency" = "build-all" ];then
        adu_common_dir="${WORK_ROOT}/baidu/adu/common"
        cd $adu_common_dir && bash build.sh
        if [ $? -ne 0 ];then
            echo "build dependency common failed."
            return 1
        fi
    fi
}

function check_dependency_hdmap_common() {
    echo "checking dependency hdmap-common..."
    if [ "$build_dependency" = "build-all" ];then
        hdmap_common_dir="${WORK_ROOT}/baidu/adu/hdmap-common"
        cd $hdmap_common_dir && bash build.sh
        if [ $? -ne 0 ];then
            echo "build dependency hdmap-common failed."
            return 1
        fi
    fi
}

#comake2 -U

check_dependency_common
if [ $? -ne 0 ];then
    echo 'check dependency common failed'
    exit 1
fi

check_dependency_hdmap_common
if [ $? -ne 0 ];then
    echo 'check dependency hdmap_common failed'
    exit 1
fi

build_dir=${WORK_ROOT}/baidu/adu/hdmap-rtk/build
rm -rf ${build_dir}
mkdir ${build_dir}


cd ${build_dir} && cmake .. -DCMAKE_BUILD_TYPE=Debug \
                    -DCMAKE_INSTALL_PREFIX=${WORK_ROOT}/baidu/adu/hdmap-rtk/output

if [ $? -ne 0 ];then
    echo 'failed to cmake'
    exit 1
fi

make -j8
if [ $? -ne 0 ];then
    echo 'failed to make'
    exit 1
fi

make install
if [ $? -ne 0 ];then
    echo 'failed to make install'
    exit 1
fi

echo "done"
