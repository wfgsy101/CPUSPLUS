export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:~/baidu/adu/common/lib
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:~/baidu/adu-3rd/protobuf/lib

./output/bin/rtk_map ./output/data/garage.csv ./output/data/base_map.bin 3.5
